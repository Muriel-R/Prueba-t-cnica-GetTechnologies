IF DB_ID('GetechnologiesTestDb') IS NULL
BEGIN
    CREATE DATABASE GetechnologiesTestDb;
END
GO
