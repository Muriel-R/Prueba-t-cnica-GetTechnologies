USE GetechnologiesTestDb;
GO

INSERT INTO dbo.Persona
(Nombre, ApellidoPaterno, ApellidoMaterno, Identificacion)
VALUES
('Juan', 'P�rez', 'L�pez', 'ABC123'),
('Mar�a', 'G�mez', NULL, 'XYZ789');

INSERT INTO dbo.Factura
(PersonaId, Monto)
VALUES
(1, 1500.00),
(1, 2500.50),
(2, 800.00);
GO
